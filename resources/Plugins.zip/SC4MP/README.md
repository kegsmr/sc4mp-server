# About these plugins

This modpack contains plugins originally included in the PMR Multiplayer Mod which are now included in SC4MP. All credit goes to the original authors named below.

*  Network Addon Mod 36 traffic simulator, by the NAM Team
*  Network Addon Mod 36 traffic data view, by the NAM Team
*  Network Addon Mod 36 zone view, by the NAM Team
*  Underwater Ferry Connectors, by jmak
*  "No_Destruction_Reconcile_Terrain_Properties.dat" by CorinaMarie