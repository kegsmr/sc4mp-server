# About these plugins

This modpack contains plugins originally included in the PMR Multiplayer Mod. These plugins are now also included as the default plugin selection for the SC4MP Multiplayer Mod.

*  Network Addon Mod 36 traffic simulator, by the NAM Team
*  Network Addon Mod 36 traffic data view, by the NAM Team
*  Network Addon Mod 36 zone view, by the NAM Team
*  Underwater Ferry Connectors, by jmak
*  "No_Destruction_Reconcile_Terrain_Properties.dat" by CorinaMarie